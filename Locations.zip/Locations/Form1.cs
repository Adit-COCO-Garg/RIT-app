﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Locations
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            pictureBox.Image = Image.FromFile(@"..\..\images\CampusMap2.PNG");
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;

            pictureBox2.Visible = false;
            pictureBox2.Image = Image.FromFile(@"..\..\images\CampusMap2.PNG");
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Start();
            dayLabel.Text = DateTime.Now.ToLongDateString();
            timeLabel.Text = DateTime.Now.ToLongTimeString();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timeLabel.Text = DateTime.Now.ToLongTimeString();
            timer1.Start();
        }

        private void pictureBox_MouseClick(object sender, MouseEventArgs e)
        {
            pictureBox2.Visible = true;
        }

        private void pictureBox2_MouseClick(object sender, MouseEventArgs e)
        {
            pictureBox2.Visible = false;
        }
    }
}
