﻿namespace Locations
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.titleLabel = new System.Windows.Forms.Label();
            this.DiningGroupBox = new System.Windows.Forms.GroupBox();
            this.diningPlaceStatus5 = new System.Windows.Forms.Label();
            this.diningPlaceStatus4 = new System.Windows.Forms.Label();
            this.diningPlaceStatus3 = new System.Windows.Forms.Label();
            this.diningPlaceStatus2 = new System.Windows.Forms.Label();
            this.diningPlaceStatus1 = new System.Windows.Forms.Label();
            this.diningPlace5 = new System.Windows.Forms.Label();
            this.diningPlace4 = new System.Windows.Forms.Label();
            this.diningPlace3 = new System.Windows.Forms.Label();
            this.diningPlace2 = new System.Windows.Forms.Label();
            this.diningPlace1 = new System.Windows.Forms.Label();
            this.diningLabel = new System.Windows.Forms.Label();
            this.labGroupBox = new System.Windows.Forms.GroupBox();
            this.building3Lab3Status = new System.Windows.Forms.Label();
            this.building3Lab2Status = new System.Windows.Forms.Label();
            this.building3Lab1Status = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.building2Lab2Status = new System.Windows.Forms.Label();
            this.building2Lab3Status = new System.Windows.Forms.Label();
            this.building1Lab3Status = new System.Windows.Forms.Label();
            this.building1Lab2Status = new System.Windows.Forms.Label();
            this.building1Lab1Status = new System.Windows.Forms.Label();
            this.building3Lab3 = new System.Windows.Forms.Label();
            this.building3Lab2 = new System.Windows.Forms.Label();
            this.building3Lab1 = new System.Windows.Forms.Label();
            this.building2Lab3 = new System.Windows.Forms.Label();
            this.building2Lab2 = new System.Windows.Forms.Label();
            this.building2Lab1 = new System.Windows.Forms.Label();
            this.building1Lab3 = new System.Windows.Forms.Label();
            this.building1Lab2 = new System.Windows.Forms.Label();
            this.building1Lab1 = new System.Windows.Forms.Label();
            this.buildingPlace3 = new System.Windows.Forms.Label();
            this.buildingPlace2 = new System.Windows.Forms.Label();
            this.buildingPlace1 = new System.Windows.Forms.Label();
            this.labLabel = new System.Windows.Forms.Label();
            this.mapGroupBox = new System.Windows.Forms.GroupBox();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.mapLabel = new System.Windows.Forms.Label();
            this.dayLabel = new System.Windows.Forms.Label();
            this.timeLabel = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.clickMeLabel = new System.Windows.Forms.Label();
            this.DiningGroupBox.SuspendLayout();
            this.labGroupBox.SuspendLayout();
            this.mapGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Font = new System.Drawing.Font("Trebuchet MS", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLabel.Location = new System.Drawing.Point(468, 33);
            this.titleLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(151, 38);
            this.titleLabel.TabIndex = 0;
            this.titleLabel.Text = "Locations";
            // 
            // DiningGroupBox
            // 
            this.DiningGroupBox.BackColor = System.Drawing.SystemColors.ControlLight;
            this.DiningGroupBox.Controls.Add(this.diningPlaceStatus5);
            this.DiningGroupBox.Controls.Add(this.diningPlaceStatus4);
            this.DiningGroupBox.Controls.Add(this.diningPlaceStatus3);
            this.DiningGroupBox.Controls.Add(this.diningPlaceStatus2);
            this.DiningGroupBox.Controls.Add(this.diningPlaceStatus1);
            this.DiningGroupBox.Controls.Add(this.diningPlace5);
            this.DiningGroupBox.Controls.Add(this.diningPlace4);
            this.DiningGroupBox.Controls.Add(this.diningPlace3);
            this.DiningGroupBox.Controls.Add(this.diningPlace2);
            this.DiningGroupBox.Controls.Add(this.diningPlace1);
            this.DiningGroupBox.Controls.Add(this.diningLabel);
            this.DiningGroupBox.Location = new System.Drawing.Point(119, 135);
            this.DiningGroupBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.DiningGroupBox.Name = "DiningGroupBox";
            this.DiningGroupBox.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.DiningGroupBox.Size = new System.Drawing.Size(230, 563);
            this.DiningGroupBox.TabIndex = 1;
            this.DiningGroupBox.TabStop = false;
            // 
            // diningPlaceStatus5
            // 
            this.diningPlaceStatus5.AutoSize = true;
            this.diningPlaceStatus5.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.diningPlaceStatus5.ForeColor = System.Drawing.Color.Red;
            this.diningPlaceStatus5.Location = new System.Drawing.Point(7, 496);
            this.diningPlaceStatus5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.diningPlaceStatus5.Name = "diningPlaceStatus5";
            this.diningPlaceStatus5.Size = new System.Drawing.Size(40, 14);
            this.diningPlaceStatus5.TabIndex = 12;
            this.diningPlaceStatus5.Text = "Closed";
            // 
            // diningPlaceStatus4
            // 
            this.diningPlaceStatus4.AutoSize = true;
            this.diningPlaceStatus4.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.diningPlaceStatus4.ForeColor = System.Drawing.Color.Red;
            this.diningPlaceStatus4.Location = new System.Drawing.Point(7, 388);
            this.diningPlaceStatus4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.diningPlaceStatus4.Name = "diningPlaceStatus4";
            this.diningPlaceStatus4.Size = new System.Drawing.Size(40, 14);
            this.diningPlaceStatus4.TabIndex = 11;
            this.diningPlaceStatus4.Text = "Closed";
            // 
            // diningPlaceStatus3
            // 
            this.diningPlaceStatus3.AutoSize = true;
            this.diningPlaceStatus3.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.diningPlaceStatus3.ForeColor = System.Drawing.Color.ForestGreen;
            this.diningPlaceStatus3.Location = new System.Drawing.Point(7, 288);
            this.diningPlaceStatus3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.diningPlaceStatus3.Name = "diningPlaceStatus3";
            this.diningPlaceStatus3.Size = new System.Drawing.Size(33, 14);
            this.diningPlaceStatus3.TabIndex = 10;
            this.diningPlaceStatus3.Text = "Open";
            // 
            // diningPlaceStatus2
            // 
            this.diningPlaceStatus2.AutoSize = true;
            this.diningPlaceStatus2.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.diningPlaceStatus2.ForeColor = System.Drawing.Color.ForestGreen;
            this.diningPlaceStatus2.Location = new System.Drawing.Point(7, 202);
            this.diningPlaceStatus2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.diningPlaceStatus2.Name = "diningPlaceStatus2";
            this.diningPlaceStatus2.Size = new System.Drawing.Size(33, 14);
            this.diningPlaceStatus2.TabIndex = 9;
            this.diningPlaceStatus2.Text = "Open";
            // 
            // diningPlaceStatus1
            // 
            this.diningPlaceStatus1.AutoSize = true;
            this.diningPlaceStatus1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.diningPlaceStatus1.ForeColor = System.Drawing.Color.ForestGreen;
            this.diningPlaceStatus1.Location = new System.Drawing.Point(7, 110);
            this.diningPlaceStatus1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.diningPlaceStatus1.Name = "diningPlaceStatus1";
            this.diningPlaceStatus1.Size = new System.Drawing.Size(33, 14);
            this.diningPlaceStatus1.TabIndex = 8;
            this.diningPlaceStatus1.Text = "Open";
            // 
            // diningPlace5
            // 
            this.diningPlace5.AutoSize = true;
            this.diningPlace5.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.diningPlace5.Location = new System.Drawing.Point(5, 466);
            this.diningPlace5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.diningPlace5.Name = "diningPlace5";
            this.diningPlace5.Size = new System.Drawing.Size(106, 16);
            this.diningPlace5.TabIndex = 5;
            this.diningPlace5.Text = "Ben and Jerry\'s";
            // 
            // diningPlace4
            // 
            this.diningPlace4.AutoSize = true;
            this.diningPlace4.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.diningPlace4.Location = new System.Drawing.Point(5, 360);
            this.diningPlace4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.diningPlace4.Name = "diningPlace4";
            this.diningPlace4.Size = new System.Drawing.Size(101, 16);
            this.diningPlace4.TabIndex = 4;
            this.diningPlace4.Text = "Brick City Cafe";
            // 
            // diningPlace3
            // 
            this.diningPlace3.AutoSize = true;
            this.diningPlace3.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.diningPlace3.Location = new System.Drawing.Point(5, 264);
            this.diningPlace3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.diningPlace3.Name = "diningPlace3";
            this.diningPlace3.Size = new System.Drawing.Size(81, 16);
            this.diningPlace3.TabIndex = 3;
            this.diningPlace3.Text = "Crossroads";
            // 
            // diningPlace2
            // 
            this.diningPlace2.AutoSize = true;
            this.diningPlace2.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.diningPlace2.Location = new System.Drawing.Point(5, 174);
            this.diningPlace2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.diningPlace2.Name = "diningPlace2";
            this.diningPlace2.Size = new System.Drawing.Size(60, 16);
            this.diningPlace2.TabIndex = 2;
            this.diningPlace2.Text = "Gracie\'s";
            // 
            // diningPlace1
            // 
            this.diningPlace1.AutoSize = true;
            this.diningPlace1.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.diningPlace1.Location = new System.Drawing.Point(5, 86);
            this.diningPlace1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.diningPlace1.Name = "diningPlace1";
            this.diningPlace1.Size = new System.Drawing.Size(100, 16);
            this.diningPlace1.TabIndex = 1;
            this.diningPlace1.Text = "The Commons";
            // 
            // diningLabel
            // 
            this.diningLabel.AutoSize = true;
            this.diningLabel.Font = new System.Drawing.Font("Trebuchet MS", 16.2F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.diningLabel.Location = new System.Drawing.Point(36, 19);
            this.diningLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.diningLabel.Name = "diningLabel";
            this.diningLabel.Size = new System.Drawing.Size(136, 27);
            this.diningLabel.TabIndex = 0;
            this.diningLabel.Text = "Dining Hours";
            // 
            // labGroupBox
            // 
            this.labGroupBox.BackColor = System.Drawing.SystemColors.ControlLight;
            this.labGroupBox.Controls.Add(this.building3Lab3Status);
            this.labGroupBox.Controls.Add(this.building3Lab2Status);
            this.labGroupBox.Controls.Add(this.building3Lab1Status);
            this.labGroupBox.Controls.Add(this.label1);
            this.labGroupBox.Controls.Add(this.building2Lab2Status);
            this.labGroupBox.Controls.Add(this.building2Lab3Status);
            this.labGroupBox.Controls.Add(this.building1Lab3Status);
            this.labGroupBox.Controls.Add(this.building1Lab2Status);
            this.labGroupBox.Controls.Add(this.building1Lab1Status);
            this.labGroupBox.Controls.Add(this.building3Lab3);
            this.labGroupBox.Controls.Add(this.building3Lab2);
            this.labGroupBox.Controls.Add(this.building3Lab1);
            this.labGroupBox.Controls.Add(this.building2Lab3);
            this.labGroupBox.Controls.Add(this.building2Lab2);
            this.labGroupBox.Controls.Add(this.building2Lab1);
            this.labGroupBox.Controls.Add(this.building1Lab3);
            this.labGroupBox.Controls.Add(this.building1Lab2);
            this.labGroupBox.Controls.Add(this.building1Lab1);
            this.labGroupBox.Controls.Add(this.buildingPlace3);
            this.labGroupBox.Controls.Add(this.buildingPlace2);
            this.labGroupBox.Controls.Add(this.buildingPlace1);
            this.labGroupBox.Controls.Add(this.labLabel);
            this.labGroupBox.Location = new System.Drawing.Point(428, 135);
            this.labGroupBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.labGroupBox.Name = "labGroupBox";
            this.labGroupBox.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.labGroupBox.Size = new System.Drawing.Size(230, 563);
            this.labGroupBox.TabIndex = 2;
            this.labGroupBox.TabStop = false;
            // 
            // building3Lab3Status
            // 
            this.building3Lab3Status.AutoSize = true;
            this.building3Lab3Status.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.building3Lab3Status.ForeColor = System.Drawing.Color.ForestGreen;
            this.building3Lab3Status.Location = new System.Drawing.Point(89, 527);
            this.building3Lab3Status.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.building3Lab3Status.Name = "building3Lab3Status";
            this.building3Lab3Status.Size = new System.Drawing.Size(33, 14);
            this.building3Lab3Status.TabIndex = 24;
            this.building3Lab3Status.Text = "Open";
            // 
            // building3Lab2Status
            // 
            this.building3Lab2Status.AutoSize = true;
            this.building3Lab2Status.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.building3Lab2Status.ForeColor = System.Drawing.Color.ForestGreen;
            this.building3Lab2Status.Location = new System.Drawing.Point(144, 487);
            this.building3Lab2Status.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.building3Lab2Status.Name = "building3Lab2Status";
            this.building3Lab2Status.Size = new System.Drawing.Size(33, 14);
            this.building3Lab2Status.TabIndex = 23;
            this.building3Lab2Status.Text = "Open";
            // 
            // building3Lab1Status
            // 
            this.building3Lab1Status.AutoSize = true;
            this.building3Lab1Status.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.building3Lab1Status.ForeColor = System.Drawing.Color.ForestGreen;
            this.building3Lab1Status.Location = new System.Drawing.Point(91, 449);
            this.building3Lab1Status.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.building3Lab1Status.Name = "building3Lab1Status";
            this.building3Lab1Status.Size = new System.Drawing.Size(33, 14);
            this.building3Lab1Status.TabIndex = 22;
            this.building3Lab1Status.Text = "Open";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(82, 285);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 14);
            this.label1.TabIndex = 21;
            this.label1.Text = "Closed";
            // 
            // building2Lab2Status
            // 
            this.building2Lab2Status.AutoSize = true;
            this.building2Lab2Status.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.building2Lab2Status.ForeColor = System.Drawing.Color.Red;
            this.building2Lab2Status.Location = new System.Drawing.Point(137, 325);
            this.building2Lab2Status.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.building2Lab2Status.Name = "building2Lab2Status";
            this.building2Lab2Status.Size = new System.Drawing.Size(40, 14);
            this.building2Lab2Status.TabIndex = 20;
            this.building2Lab2Status.Text = "Closed";
            // 
            // building2Lab3Status
            // 
            this.building2Lab3Status.AutoSize = true;
            this.building2Lab3Status.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.building2Lab3Status.ForeColor = System.Drawing.Color.ForestGreen;
            this.building2Lab3Status.Location = new System.Drawing.Point(121, 368);
            this.building2Lab3Status.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.building2Lab3Status.Name = "building2Lab3Status";
            this.building2Lab3Status.Size = new System.Drawing.Size(33, 14);
            this.building2Lab3Status.TabIndex = 19;
            this.building2Lab3Status.Text = "Open";
            // 
            // building1Lab3Status
            // 
            this.building1Lab3Status.AutoSize = true;
            this.building1Lab3Status.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.building1Lab3Status.ForeColor = System.Drawing.Color.Red;
            this.building1Lab3Status.Location = new System.Drawing.Point(111, 202);
            this.building1Lab3Status.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.building1Lab3Status.Name = "building1Lab3Status";
            this.building1Lab3Status.Size = new System.Drawing.Size(40, 14);
            this.building1Lab3Status.TabIndex = 18;
            this.building1Lab3Status.Text = "Closed";
            // 
            // building1Lab2Status
            // 
            this.building1Lab2Status.AutoSize = true;
            this.building1Lab2Status.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.building1Lab2Status.ForeColor = System.Drawing.Color.ForestGreen;
            this.building1Lab2Status.Location = new System.Drawing.Point(144, 158);
            this.building1Lab2Status.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.building1Lab2Status.Name = "building1Lab2Status";
            this.building1Lab2Status.Size = new System.Drawing.Size(33, 14);
            this.building1Lab2Status.TabIndex = 17;
            this.building1Lab2Status.Text = "Open";
            // 
            // building1Lab1Status
            // 
            this.building1Lab1Status.AutoSize = true;
            this.building1Lab1Status.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.building1Lab1Status.ForeColor = System.Drawing.Color.ForestGreen;
            this.building1Lab1Status.Location = new System.Drawing.Point(83, 121);
            this.building1Lab1Status.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.building1Lab1Status.Name = "building1Lab1Status";
            this.building1Lab1Status.Size = new System.Drawing.Size(33, 14);
            this.building1Lab1Status.TabIndex = 13;
            this.building1Lab1Status.Text = "Open";
            // 
            // building3Lab3
            // 
            this.building3Lab3.AutoSize = true;
            this.building3Lab3.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.building3Lab3.Location = new System.Drawing.Point(26, 527);
            this.building3Lab3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.building3Lab3.Name = "building3Lab3";
            this.building3Lab3.Size = new System.Drawing.Size(59, 14);
            this.building3Lab3.TabIndex = 16;
            this.building3Lab3.Text = "Studio 96 -";
            // 
            // building3Lab2
            // 
            this.building3Lab2.AutoSize = true;
            this.building3Lab2.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.building3Lab2.Location = new System.Drawing.Point(26, 487);
            this.building3Lab2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.building3Lab2.Name = "building3Lab2";
            this.building3Lab2.Size = new System.Drawing.Size(112, 14);
            this.building3Lab2.TabIndex = 15;
            this.building3Lab2.Text = "Booth Computer Lab -";
            // 
            // building3Lab1
            // 
            this.building3Lab1.AutoSize = true;
            this.building3Lab1.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.building3Lab1.Location = new System.Drawing.Point(26, 449);
            this.building3Lab1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.building3Lab1.Name = "building3Lab1";
            this.building3Lab1.Size = new System.Drawing.Size(62, 14);
            this.building3Lab1.TabIndex = 14;
            this.building3Lab1.Text = "3-D World -";
            // 
            // building2Lab3
            // 
            this.building2Lab3.AutoSize = true;
            this.building2Lab3.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.building2Lab3.Location = new System.Drawing.Point(26, 368);
            this.building2Lab3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.building2Lab3.Name = "building2Lab3";
            this.building2Lab3.Size = new System.Drawing.Size(89, 14);
            this.building2Lab3.TabIndex = 13;
            this.building2Lab3.Text = "New Media Lab -";
            // 
            // building2Lab2
            // 
            this.building2Lab2.AutoSize = true;
            this.building2Lab2.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.building2Lab2.Location = new System.Drawing.Point(26, 325);
            this.building2Lab2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.building2Lab2.Name = "building2Lab2";
            this.building2Lab2.Size = new System.Drawing.Size(104, 14);
            this.building2Lab2.TabIndex = 12;
            this.building2Lab2.Text = "Gannett Multimedia -";
            // 
            // building2Lab1
            // 
            this.building2Lab1.AutoSize = true;
            this.building2Lab1.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.building2Lab1.Location = new System.Drawing.Point(26, 285);
            this.building2Lab1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.building2Lab1.Name = "building2Lab1";
            this.building2Lab1.Size = new System.Drawing.Size(52, 14);
            this.building2Lab1.TabIndex = 11;
            this.building2Lab1.Text = "3-D Lab -";
            // 
            // building1Lab3
            // 
            this.building1Lab3.AutoSize = true;
            this.building1Lab3.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.building1Lab3.Location = new System.Drawing.Point(26, 202);
            this.building1Lab3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.building1Lab3.Name = "building1Lab3";
            this.building1Lab3.Size = new System.Drawing.Size(81, 14);
            this.building1Lab3.TabIndex = 10;
            this.building1Lab3.Text = "Computer Lab -";
            // 
            // building1Lab2
            // 
            this.building1Lab2.AutoSize = true;
            this.building1Lab2.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.building1Lab2.Location = new System.Drawing.Point(26, 158);
            this.building1Lab2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.building1Lab2.Name = "building1Lab2";
            this.building1Lab2.Size = new System.Drawing.Size(109, 14);
            this.building1Lab2.TabIndex = 9;
            this.building1Lab2.Text = "Computer Tools Lab -";
            // 
            // building1Lab1
            // 
            this.building1Lab1.AutoSize = true;
            this.building1Lab1.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.building1Lab1.Location = new System.Drawing.Point(26, 121);
            this.building1Lab1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.building1Lab1.Name = "building1Lab1";
            this.building1Lab1.Size = new System.Drawing.Size(52, 14);
            this.building1Lab1.TabIndex = 8;
            this.building1Lab1.Text = "ASI Lab -";
            // 
            // buildingPlace3
            // 
            this.buildingPlace3.AutoSize = true;
            this.buildingPlace3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buildingPlace3.Location = new System.Drawing.Point(5, 409);
            this.buildingPlace3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.buildingPlace3.Name = "buildingPlace3";
            this.buildingPlace3.Size = new System.Drawing.Size(56, 19);
            this.buildingPlace3.TabIndex = 7;
            this.buildingPlace3.Text = "Booth";
            // 
            // buildingPlace2
            // 
            this.buildingPlace2.AutoSize = true;
            this.buildingPlace2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buildingPlace2.Location = new System.Drawing.Point(5, 247);
            this.buildingPlace2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.buildingPlace2.Name = "buildingPlace2";
            this.buildingPlace2.Size = new System.Drawing.Size(69, 19);
            this.buildingPlace2.TabIndex = 6;
            this.buildingPlace2.Text = "Gannett";
            // 
            // buildingPlace1
            // 
            this.buildingPlace1.AutoSize = true;
            this.buildingPlace1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buildingPlace1.Location = new System.Drawing.Point(5, 86);
            this.buildingPlace1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.buildingPlace1.Name = "buildingPlace1";
            this.buildingPlace1.Size = new System.Drawing.Size(72, 19);
            this.buildingPlace1.TabIndex = 5;
            this.buildingPlace1.Text = "Gleason";
            // 
            // labLabel
            // 
            this.labLabel.AutoSize = true;
            this.labLabel.Font = new System.Drawing.Font("Trebuchet MS", 16.2F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labLabel.Location = new System.Drawing.Point(54, 19);
            this.labLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labLabel.Name = "labLabel";
            this.labLabel.Size = new System.Drawing.Size(110, 27);
            this.labLabel.TabIndex = 4;
            this.labLabel.Text = "Lab Hours";
            // 
            // mapGroupBox
            // 
            this.mapGroupBox.BackColor = System.Drawing.SystemColors.ControlLight;
            this.mapGroupBox.Controls.Add(this.clickMeLabel);
            this.mapGroupBox.Controls.Add(this.pictureBox);
            this.mapGroupBox.Controls.Add(this.mapLabel);
            this.mapGroupBox.Location = new System.Drawing.Point(736, 135);
            this.mapGroupBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.mapGroupBox.Name = "mapGroupBox";
            this.mapGroupBox.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.mapGroupBox.Size = new System.Drawing.Size(226, 563);
            this.mapGroupBox.TabIndex = 3;
            this.mapGroupBox.TabStop = false;
            // 
            // pictureBox
            // 
            this.pictureBox.Location = new System.Drawing.Point(32, 206);
            this.pictureBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(162, 222);
            this.pictureBox.TabIndex = 8;
            this.pictureBox.TabStop = false;
            this.pictureBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBox_MouseClick);
            // 
            // mapLabel
            // 
            this.mapLabel.AutoSize = true;
            this.mapLabel.Font = new System.Drawing.Font("Trebuchet MS", 16.2F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mapLabel.Location = new System.Drawing.Point(42, 19);
            this.mapLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.mapLabel.Name = "mapLabel";
            this.mapLabel.Size = new System.Drawing.Size(135, 27);
            this.mapLabel.TabIndex = 0;
            this.mapLabel.Text = "Campus Map";
            // 
            // dayLabel
            // 
            this.dayLabel.AutoSize = true;
            this.dayLabel.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dayLabel.Location = new System.Drawing.Point(116, 46);
            this.dayLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.dayLabel.Name = "dayLabel";
            this.dayLabel.Size = new System.Drawing.Size(54, 22);
            this.dayLabel.TabIndex = 6;
            this.dayLabel.Text = "label1";
            // 
            // timeLabel
            // 
            this.timeLabel.AutoSize = true;
            this.timeLabel.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timeLabel.Location = new System.Drawing.Point(116, 86);
            this.timeLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.timeLabel.Name = "timeLabel";
            this.timeLabel.Size = new System.Drawing.Size(54, 22);
            this.timeLabel.TabIndex = 7;
            this.timeLabel.Text = "label2";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(21, 138);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(995, 560);
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBox2_MouseClick);
            // 
            // clickMeLabel
            // 
            this.clickMeLabel.AutoSize = true;
            this.clickMeLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clickMeLabel.Location = new System.Drawing.Point(46, 161);
            this.clickMeLabel.Name = "clickMeLabel";
            this.clickMeLabel.Size = new System.Drawing.Size(133, 19);
            this.clickMeLabel.TabIndex = 10;
            this.clickMeLabel.Text = "Click To Expand";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1038, 743);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.timeLabel);
            this.Controls.Add(this.dayLabel);
            this.Controls.Add(this.mapGroupBox);
            this.Controls.Add(this.labGroupBox);
            this.Controls.Add(this.DiningGroupBox);
            this.Controls.Add(this.titleLabel);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.DiningGroupBox.ResumeLayout(false);
            this.DiningGroupBox.PerformLayout();
            this.labGroupBox.ResumeLayout(false);
            this.labGroupBox.PerformLayout();
            this.mapGroupBox.ResumeLayout(false);
            this.mapGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.GroupBox DiningGroupBox;
        private System.Windows.Forms.Label diningLabel;
        private System.Windows.Forms.GroupBox labGroupBox;
        private System.Windows.Forms.GroupBox mapGroupBox;
        private System.Windows.Forms.Label diningPlace5;
        private System.Windows.Forms.Label diningPlace4;
        private System.Windows.Forms.Label diningPlace3;
        private System.Windows.Forms.Label diningPlace2;
        private System.Windows.Forms.Label diningPlace1;
        private System.Windows.Forms.Label labLabel;
        private System.Windows.Forms.Label mapLabel;
        private System.Windows.Forms.Label dayLabel;
        private System.Windows.Forms.Label timeLabel;
        private System.Windows.Forms.Label diningPlaceStatus5;
        private System.Windows.Forms.Label diningPlaceStatus4;
        private System.Windows.Forms.Label diningPlaceStatus3;
        private System.Windows.Forms.Label diningPlaceStatus2;
        private System.Windows.Forms.Label diningPlaceStatus1;
        private System.Windows.Forms.Label building2Lab3;
        private System.Windows.Forms.Label building2Lab2;
        private System.Windows.Forms.Label building2Lab1;
        private System.Windows.Forms.Label building1Lab3;
        private System.Windows.Forms.Label building1Lab2;
        private System.Windows.Forms.Label building1Lab1;
        private System.Windows.Forms.Label buildingPlace3;
        private System.Windows.Forms.Label buildingPlace2;
        private System.Windows.Forms.Label buildingPlace1;
        private System.Windows.Forms.Label building3Lab3Status;
        private System.Windows.Forms.Label building3Lab2Status;
        private System.Windows.Forms.Label building3Lab1Status;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label building2Lab2Status;
        private System.Windows.Forms.Label building2Lab3Status;
        private System.Windows.Forms.Label building1Lab3Status;
        private System.Windows.Forms.Label building1Lab2Status;
        private System.Windows.Forms.Label building1Lab1Status;
        private System.Windows.Forms.Label building3Lab3;
        private System.Windows.Forms.Label building3Lab2;
        private System.Windows.Forms.Label building3Lab1;
        private System.Windows.Forms.PictureBox pictureBox;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label clickMeLabel;
    }
}

